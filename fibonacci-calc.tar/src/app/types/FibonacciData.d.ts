export interface FibonacciData {
    id: number,
    fibonacci_number: number
};
